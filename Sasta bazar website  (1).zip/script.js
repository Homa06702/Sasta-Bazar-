// script.js - Complete Working Code for Sasta Bazar

// Main function when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Handle product selection on homepage
    if (document.querySelector('.product-list')) {
        setupProductButtons();
    }
    
    // Handle order page functionality
    if (document.getElementById('orderForm')) {
        initializeOrderPage();
    }
});

// Set up product buttons on homepage
function setupProductButtons() {
    const buyButtons = document.querySelectorAll('.buy-btn');
    
    buyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const product = {
                id: this.getAttribute('data-id'),
                name: this.getAttribute('data-name'),
                price: this.getAttribute('data-price')
            };
            
            // Save product to localStorage
            localStorage.setItem('selectedProduct', JSON.stringify(product));
            
            // Redirect to order page
            window.location.href = 'order.html';
        });
    });
}

// Initialize order page functionality
function initializeOrderPage() {
    loadOrderSummary();
    setupPincodeAutoFill();
    setupFormSubmission();
}

// Load product summary on order page
function loadOrderSummary() {
    const product = JSON.parse(localStorage.getItem('selectedProduct'));
    const orderSummary = document.getElementById('order-summary');
    
    if (product && orderSummary) {
        orderSummary.innerHTML = `
            <h3>${product.name}</h3>
            <p><strong>Price:</strong> ₹${product.price}</p>
            <hr>
        `;
        
        // Set hidden form fields
        document.getElementById('product-id').value = product.id;
        document.getElementById('product-name').value = product.name;
        document.getElementById('product-price').value = product.price;
    }
}

// Auto-fill state/district based on pincode
function setupPincodeAutoFill() {
    const pincodeInput = document.getElementById('pincode');
    
    pincodeInput.addEventListener('blur', function() {
        const pincode = this.value.trim();
        
        if (pincode.length === 6 && /^\d+$/.test(pincode)) {
            fetchPincodeDetails(pincode);
        } else if (pincode.length > 0) {
            alert('Please enter a valid 6-digit PIN code');
        }
    });
}

// Fetch pincode details from API
function fetchPincodeDetails(pincode) {
    showLoadingState(true);
    
    fetch(`https://api.postalpincode.in/pincode/${pincode}`)
        .then(response => response.json())
        .then(data => {
            if (data[0].Status === "Success") {
                document.getElementById('state').value = data[0].PostOffice[0].State;
                document.getElementById('district').value = data[0].PostOffice[0].District;
            } else {
                alert('PIN code not found. Please enter manually.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error fetching PIN code details. Please enter manually.');
        })
        .finally(() => showLoadingState(false));
}

// Show/hide loading state
function showLoadingState(show) {
    const pincodeField = document.getElementById('pincode');
    if (show) {
        pincodeField.classList.add('loading');
    } else {
        pincodeField.classList.remove('loading');
    }
}

// Handle form submission
function setupFormSubmission() {
    const orderForm = document.getElementById('orderForm');
    
    orderForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        if (!validateForm()) {
            return;
        }
        
        // Prepare WhatsApp message
        const whatsappUrl = prepareWhatsAppMessage();
        
        // Open WhatsApp
        window.open(whatsappUrl, '_blank');
        
        // Optional: Reset form
        // orderForm.reset();
    });
}

// Validate form fields
function validateForm() {
    const requiredFields = ['name', 'phone', 'pincode', 'full-address'];
    let isValid = true;
    
    requiredFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (!field.value.trim()) {
            field.classList.add('error');
            isValid = false;
        } else {
            field.classList.remove('error');
        }
    });
    
    // Validate phone number
    const phone = document.getElementById('phone').value;
    if (phone.length !== 10 || !/^\d+$/.test(phone)) {
        document.getElementById('phone').classList.add('error');
        alert('Please enter a valid 10-digit phone number');
        isValid = false;
    }
    
    return isValid;
}

// Prepare WhatsApp message URL
function prepareWhatsAppMessage() {
    // Get form values
    const formData = {
        name: document.getElementById('name').value,
        phone: document.getElementById('phone').value,
        product: document.getElementById('product-name').value,
        price: document.getElementById('product-price').value,
        pincode: document.getElementById('pincode').value,
        state: document.getElementById('state').value,
        district: document.getElementById('district').value,
        address: document.getElementById('full-address').value
    };
    
    // Create message template
    const message = `*Sasta Bazar - New Order*
    
🛒 *Product:* ${formData.product}
💰 *Price:* ₹${formData.price}

👤 *Customer Details:*
• Name: ${formData.name}
• Phone: ${formData.phone}

🏠 *Shipping Address:*
${formData.address}
${formData.district}, ${formData.state}
PIN: ${formData.pincode}

Thank you for your order!`;

    // Encode message for URL
    const encodedMessage = encodeURIComponent(message);
    
    // REPLACE THIS NUMBER WITH YOUR WHATSAPP BUSINESS NUMBER
    const whatsappNumber = '917369847683';
    
    // Return WhatsApp URL
    return `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;
}